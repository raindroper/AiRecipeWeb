import { UserDbWrapper } from './userDbWrapper.js'
import { UserProfile } from './UserProfile.js'

let myHandler = async function (event, context, callback, logger) {
  logger.info('>>> [STEP 1] Handler Started (user-center) - ESM.')

  let body = {}
  try {
    if (event.body) {
      body = typeof event.body === 'string' ? JSON.parse(event.body) : event.body
    } else {
      body = event
    }
    logger.info('>>> [STEP 2] Parsed Body: ' + JSON.stringify(body))
  } catch (e) {
    return callback({ ret: { code: 400, desc: 'Invalid JSON' } })
  }

  const { action, userId, data } = body

  if (!userId) {
    return callback({ ret: { code: 400, desc: 'Missing userId' } })
  }

  let db
  try {
    db = new UserDbWrapper()
  } catch (e) {
    logger.error('DB Init Failed: ' + e.message)
    return callback({ ret: { code: 500, desc: 'DB Init Failed: ' + e.message } })
  }

  try {
    if (action === 'get') {
      const userList = await db.queryUser(userId)
      if (!userList || userList.length === 0) {
        return callback({ ret: { code: 404, desc: 'User not found' } })
      }
      const user = userList[0]
      user.password = undefined
      return callback({
        ret: { code: 0, desc: 'Success' },
        result: user,
      })
    } else if (action === 'update') {
      if (!data) return callback({ ret: { code: 400, desc: 'Missing data' } })

      const userList = await db.queryUser(userId)
      if (!userList || userList.length === 0) {
        return callback({ ret: { code: 404, desc: 'User not found' } })
      }
      const existingUser = userList[0]

      const newUser = new UserProfile()
      Object.assign(newUser, existingUser)
      delete data.id
      Object.assign(newUser, data)
      newUser.id = userId

      await db.upsertUser(newUser)

      newUser.password = undefined
      return callback({
        ret: { code: 0, desc: 'Update Success' },
        result: newUser,
      })
    } else {
      return callback({ ret: { code: 400, desc: 'Unknown action' } })
    }
  } catch (error) {
    logger.error('System Error: ' + error.message)
    return callback({
      ret: { code: 500, desc: 'Server Error: ' + error.message },
    })
  }
}

export { myHandler }
