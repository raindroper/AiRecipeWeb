import { cloud } from '@hw-agconnect/cloud-server'
import { UserProfile } from './UserProfile.js'

const ZONE_NAME = 'devDB'

export class UserDbWrapper {
  constructor() {
    console.log(`[UserDbWrapper] Initializing... Zone: ${ZONE_NAME}`)
    try {
      // Debug logging to ensure class is loaded correctly
      if (!UserProfile) {
        console.error('[UserDbWrapper] Critical: UserProfile class is undefined!')
      } else {
        console.log('[UserDbWrapper] UserProfile class loaded.')
      }

      this.collection = cloud.database({ zoneName: ZONE_NAME }).collection(UserProfile)
      console.log('[UserDbWrapper] Collection created.')
    } catch (e) {
      console.error('[UserDbWrapper] Collection init failed!', e)
      throw e
    }
  }

  async queryUser(userId) {
    console.log(`[UserDbWrapper] queryUser > ID: ${userId}`)
    try {
      if (!userId) {
        return []
      }
      const query = this.collection.query().equalTo('id', userId)
      const res = await query.get()
      return res
    } catch (error) {
      console.error(`[UserDbWrapper] queryUser error:`, error)
      throw error
    }
  }

  async upsertUser(userInfo) {
    console.log(`[UserDbWrapper] upsertUser > Data: ${JSON.stringify(userInfo)}`)
    try {
      const res = await this.collection.upsert(userInfo)
      console.log(`[UserDbWrapper] upsertUser > Success. Rows: ${res}`)
      return res
    } catch (error) {
      console.error(`[UserDbWrapper] upsertUser error:`, error)
      throw error
    }
  }
}
